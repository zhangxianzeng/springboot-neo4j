package com.heliteq.dataframework.dashboard;

import com.heliteq.dataframework.dashboard.server.Response.data.DataResponse;
import com.heliteq.dataframework.dashboard.server.backend.neo4j.executor.DataExecutor;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.neo4j.driver.Driver;
import org.neo4j.driver.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DashboardApplication.class)
public class ExampleApplicationTests {

    @Autowired
    private Driver driver;

    @Autowired
    private DataExecutor dataExecutor;

    @Before
    public void createTestData() {
        Session session = driver.session();
        session.run(
                "MERGE (gtx:SYS_TEST_Hero{name:'钢铁侠'})\n" +
                        "MERGE (ls:SYS_TEST_Hero{name:'雷神'})\n" +
                        "MERGE (fl:SYS_TEST_Organization{name:'复仇者联盟'})\n" +
                        "MERGE (gtx) -[:SYS_TEST_BELONG_TO]-> (fl)\n" +
                        "MERGE (ls) -[:SYS_TEST_BELONG_TO]-> (fl)");
        session.close();
    }

    @After
    public void dropTestData() {
        Session session = driver.session();
        session.run("MATCH (hero:SYS_TEST_Hero) DETACH DELETE hero");
        session.run("MATCH (og:SYS_TEST_Organization) DETACH DELETE og");
        session.close();
    }

    @Test
    public void contextLoads() {
        DataResponse result = dataExecutor.execute("MATCH (gtx:SYS_TEST_Hero{name:'钢铁侠'}) RETURN gtx");
        Assert.assertEquals(1,result.getNodes().size());
        result.getNodes().forEach(node -> {
            Assert.assertTrue(node.getLabels().contains("SYS_TEST_Hero"));
            Assert.assertTrue(node.getProperties().containsValue("钢铁侠"));
        });
    }

}
