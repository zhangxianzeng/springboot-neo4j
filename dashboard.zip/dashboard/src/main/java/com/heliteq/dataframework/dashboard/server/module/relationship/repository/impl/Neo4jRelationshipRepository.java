package com.heliteq.dataframework.dashboard.server.module.relationship.repository.impl;

import com.heliteq.dataframework.dashboard.server.Response.data.Path;
import com.heliteq.dataframework.dashboard.server.Response.data.Relationship;
import com.heliteq.dataframework.dashboard.server.backend.neo4j.executor.DataExecutor;
import com.heliteq.dataframework.dashboard.server.module.relationship.repository.RelationshipRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public class Neo4jRelationshipRepository implements RelationshipRepository {
    @Autowired
    private DataExecutor dataRecordResolver;
    //根据关系的标签查询出具有该关系的整条路径
    @Override
    public Collection<Path.Segment> getRelationshipSchemaByLabel(String label) {
        String cql="match p=(n)-[r]-(m) where type(r)={label} return p";
        Map<String, Object> params = new HashMap<>();
        params.put("label",label);
        Collection<Path> paths = dataRecordResolver.execute(cql, params).getPaths();
        List<Path.Segment> segments = new ArrayList<>();
        paths.forEach(path -> {
            segments.addAll(path.getSegments());
        });
        return segments;
    }
    //根据关系标签查找出具体的关系属性
    @Override
    public Collection<Relationship> getByLabelRelationship(String label) {
        String cql="match p=(n)-[r]-(m) where type(r)={label} return r";
        Map<String, Object> params = new HashMap<>();
        params.put("label",label);
        return dataRecordResolver.execute(cql,params).getRelationships();
    }
}
