package com.heliteq.dataframework.dashboard.common.statics;

public class GraphStatics {
    public static final String SCHEMA_NODE_LABEL = "DB_Schema";
    public static final String SCHEMA_RELATION_LABEL = "DB_SCHEMA_REL";
    public static final String SCHEMA_NAME_PROPERTY = "db_schema_name";


}
