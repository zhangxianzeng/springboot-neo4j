package com.heliteq.dataframework.dashboard.server.backend.neo4j.executor;

import com.heliteq.dataframework.dashboard.server.Response.DatabaseResponseTag;
import org.neo4j.driver.*;
import org.neo4j.driver.internal.InternalNode;
import org.neo4j.driver.internal.InternalRelationship;
import org.neo4j.driver.types.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.support.TransactionSynchronizationManager;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class Executor<T extends DatabaseResponseTag> {
    @Autowired
    protected Driver driver;

    private Logger logger = LoggerFactory.getLogger(this.getClass());

    public final T execute(String cql) {
        return execute(cql, new HashMap<>());
    }

    public final T execute(String cql, Map<String, Object> param) {
        Transaction transaction = (Transaction) TransactionSynchronizationManager.getResource(this.driver);
        return execute(cql, param, transaction);
    }

    public final T execute(String cql, Transaction transaction) {
        return execute(cql, new HashMap<>(), transaction);
    }

    public final T execute(String cql, Map<String, Object> param, Transaction transaction) {
        Result statementResult;
        Session localSession = null;
        boolean isLocalSession = transaction == null;
        try {
            if (isLocalSession) {
                localSession = driver.session();
                statementResult = localSession.run(cql, param);
            }
            else
                statementResult = transaction.run(cql, param);
            List<Record> records = statementResult.list();
            return resolveRecord(records);
        } catch (Exception e) {
            throw e;
        } finally {
            if (isLocalSession)
                localSession.close();
        }
    }

    private T resolveRecord (List<Record> records) {
        T response = createResponse();
        records.forEach(record -> {
            record.keys().forEach(key -> {
                Value value = record.get(key);
                String type = value.type().name();
                switch (type) {
                    case "PATH":
                        Path path = value.asPath();
                        resolvePath(path, response);
                        break;
                    case "NODE":
                        InternalNode internalNode = (InternalNode) value.asNode();
                        resolveNode(internalNode, response);
                        break;
                    case "RELATIONSHIP":
                        InternalRelationship internalRelation = (InternalRelationship) value.asRelationship();
                        resolveRelation(internalRelation, response);
                        break;
                    default:
                        resolveParam(key, value, response);
                        break;
                }
            });
        });
        return response;
    }


    abstract protected T createResponse();

    abstract protected void resolveNode(InternalNode internalNode, T response);

    abstract protected void resolveRelation(InternalRelationship internalRelation, T response);

    abstract protected void resolvePath(Path path, T response);

    abstract protected void resolveParam(String key, Value value, T response);


}
