package com.heliteq.dataframework.dashboard.init;

import com.heliteq.dataframework.dashboard.common.statics.GraphStatics;
import org.neo4j.driver.Driver;
import org.neo4j.driver.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.stereotype.Component;

@Component
public class Neo4jInitialization extends DatabaseInitialization {
    private Logger logger = LoggerFactory.getLogger(Neo4jInitialization.class);
    protected Driver driver;

    @Autowired
    public Neo4jInitialization(Driver driver) {
        this.driver = driver;
    }

    //在项目启动时初始化一个自定义的schema
    @Override
    protected void initSchema(ApplicationArguments args) throws Exception {
        logger.info("Neo4j schema initializing ...");
        Session session = driver.session();
        try {
            // 生成的schema中不包含孤立节点的label，因为schema主要是用来查找关系的，排除孤立节点可以提高生成速度
            session.run("MATCH(g:" + GraphStatics.SCHEMA_NODE_LABEL + ") DETACH DELETE g");
            session.run("MATCH(n)-[r]->(m)\n" +
                    "WITH labels(n) AS ns,type(r) AS r,labels(m) AS ms\n" +
                    "UNWIND ns AS n\n" +
                    "UNWIND ms AS m\n" +
                    "MERGE(t:" + GraphStatics.SCHEMA_NODE_LABEL + "{" + GraphStatics.SCHEMA_NAME_PROPERTY + ":n})\n" +
                    "MERGE(f:" + GraphStatics.SCHEMA_NODE_LABEL + "{" + GraphStatics.SCHEMA_NAME_PROPERTY + ":m})\n" +
                    "MERGE(t)-[:" + GraphStatics.SCHEMA_RELATION_LABEL + "{" + GraphStatics.SCHEMA_NAME_PROPERTY + ":r}]->(f)");
        } catch (Exception e) {
            throw e;
        } finally {
            session.close();
        }
        logger.info("Neo4j schema finished");
    }
}
