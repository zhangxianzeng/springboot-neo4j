package com.heliteq.dataframework.dashboard.server.backend.neo4j.executor;

import com.heliteq.dataframework.dashboard.server.Response.data.DataResponse;
import com.heliteq.dataframework.dashboard.server.Response.data.Node;
import com.heliteq.dataframework.dashboard.server.Response.data.Path;
import com.heliteq.dataframework.dashboard.server.Response.data.Relationship;
import org.neo4j.driver.Value;
import org.neo4j.driver.internal.InternalNode;
import org.neo4j.driver.internal.InternalRelationship;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;

@Component
public class DataExecutor extends Executor<DataResponse> {

    @Override
    protected DataResponse createResponse() {
        DataResponse dataResponse = new DataResponse();
        dataResponse.setNodes(new ArrayList<>());
        dataResponse.setRelationships(new ArrayList<>());
        dataResponse.setPaths(new ArrayList<>());
        dataResponse.setParams(new HashMap<>());
        return dataResponse;
    }

    @Override
    protected void resolveNode(InternalNode internalNode, DataResponse response) {
        Node node = createNode(internalNode);
        response.getNodes().add(node);
    }

    @Override
    protected void resolveRelation(InternalRelationship internalRelation, DataResponse response) {
        Relationship relationship = createRelation(internalRelation);
        response.getRelationships().add(relationship);
    }

    @Override
    protected void resolvePath(org.neo4j.driver.types.Path path, DataResponse response) {
        Path p = new Path();
        p.setSegments(new ArrayList<>());
        path.forEach(segment -> {
            Node start = (createNode((InternalNode) segment.start()));
            Node end = (createNode((InternalNode) segment.end()));
            Relationship relation = (createRelation((InternalRelationship) segment.relationship()));
            Path.Segment s = p.new Segment();
            s.setStartNode(start);
            s.setEndNode(end);
            s.setRelationship(relation);
            p.getSegments().add(s);
        });

        response.getPaths().add(p);
    }


    private Node createNode(InternalNode internalNode) {
        Node node = new Node();
        node.setNodeId(internalNode.id());
        node.setLabels(internalNode.labels());
        node.setProperties(internalNode.asMap());
        return node;
    }

    private Relationship createRelation(InternalRelationship internalRelation) {
        Relationship relationship = new Relationship();
        relationship.setRelationshipId(internalRelation.id());
        relationship.setTypes(internalRelation.type());
        relationship.setStartNodeId(internalRelation.startNodeId());
        relationship.setEndNodeId(internalRelation.endNodeId());
        relationship.setProperties(internalRelation.asMap());
        return relationship;
    }

    @Override
    protected void resolveParam(String key, Value value, DataResponse response) {
        response.getParams().put(key,value.asObject());
    }

}
