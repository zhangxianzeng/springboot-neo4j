package com.heliteq.dataframework.dashboard.server.module.relationship.service;

import com.heliteq.dataframework.dashboard.server.Response.data.Path;
import com.heliteq.dataframework.dashboard.server.Response.data.Relationship;
import com.heliteq.dataframework.dashboard.server.module.relationship.repository.RelationshipRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class RelationshipService {
    @Autowired
    private RelationshipRepository relationshipRepository;
//根据关系的标签查询出具有该关系的整条路径
    public Collection<Path.Segment> getRelationshipByLabel(String label){
        return relationshipRepository.getRelationshipSchemaByLabel(label);
    }
    //根据关系标签查找关系属性
    public Collection<Relationship> getByLabelRelationship(String label){
        return  relationshipRepository.getByLabelRelationship(label);
    }
}
