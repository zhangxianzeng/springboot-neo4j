package com.heliteq.dataframework.dashboard.server.backend.neo4j.transaction;

import org.neo4j.driver.Driver;
import org.neo4j.driver.Session;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.TransactionException;
import org.springframework.transaction.support.AbstractPlatformTransactionManager;
import org.springframework.transaction.support.DefaultTransactionStatus;
import org.springframework.transaction.support.ResourceTransactionManager;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.util.Assert;

public class Neo4jTransactionManager extends AbstractPlatformTransactionManager implements ResourceTransactionManager, InitializingBean {
    private Logger logger = LoggerFactory.getLogger(Neo4jTransactionManager.class);

    private Driver driver;

    public Neo4jTransactionManager(Driver driver) {
        this.driver = driver;
        afterPropertiesSet();
    }

    public Driver getDriver() {
        return this.driver;
    }

    public void setDriver(Driver driver) {
        this.driver = driver;
    }

    protected Driver obtainDriver() {
        Driver dataSource = getDriver();
        Assert.state(dataSource != null, "No driver set");
        return dataSource;
    }

    @Override
    public void afterPropertiesSet() {
        if (getDriver() == null) {
            throw new IllegalArgumentException("Property 'driver' is required");
        }
    }

    @Override
    public Object getResourceFactory() {
        return obtainDriver();
    }


    @Override
    protected Object doGetTransaction() throws TransactionException {
        Session session = driver.session();
        Neo4jTransactionObject transactionObject = new Neo4jTransactionObject(session);
        TransactionSynchronizationManager.bindResource(this.driver, transactionObject.getTransaction());
        return transactionObject;
    }


    @Override
    protected void doBegin(Object transaction, TransactionDefinition definition) throws TransactionException {
    }

    @Override
    protected void doCommit(DefaultTransactionStatus status) throws TransactionException {
        Neo4jTransactionObject transactionObject = (Neo4jTransactionObject) status.getTransaction();
        transactionObject.commit();
    }

    @Override
    protected void doRollback(DefaultTransactionStatus status) throws TransactionException {
        Neo4jTransactionObject transactionObject = (Neo4jTransactionObject) status.getTransaction();
        transactionObject.rollback();
    }
}
