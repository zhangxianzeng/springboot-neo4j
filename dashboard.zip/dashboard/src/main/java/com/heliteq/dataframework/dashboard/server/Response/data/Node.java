package com.heliteq.dataframework.dashboard.server.Response.data;

import java.util.Collection;
import java.util.Map;

public class Node {
    private long nodeId;
    private Collection<String> labels;
    private Map<String, Object> properties;

    public long getNodeId() {
        return nodeId;
    }

    public void setNodeId(long nodeId) {
        this.nodeId = nodeId;
    }

    public Collection<String> getLabels() {
        return labels;
    }

    public void setLabels(Collection<String> labels) {
        this.labels = labels;
    }

    public Map<String, Object> getProperties() {
        return properties;
    }

    public void setProperties(Map<String, Object> properties) {
        this.properties = properties;
    }

    @Override
    public String toString() {
        return "Node{" +
                "nodeId=" + nodeId +
                ", labels=" + labels +
                ", properties=" + properties +
                '}';
    }
}
