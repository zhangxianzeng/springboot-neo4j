package com.heliteq.dataframework.dashboard.server.Response.data;

import java.util.List;

public class Path {
    private List<Segment> segments;

    public List<Segment> getSegments() {
        return segments;
    }

    public void setSegments(List<Segment> segments) {
        this.segments = segments;
    }

    @Override
    public String toString() {
        return "Path{" +
                "segments=" + segments +
                '}';
    }

    public class Segment {
        private Node startNode;
        private Node endNode;
        private Relationship relationship;

        public Node getStartNode() {
            return startNode;
        }

        public void setStartNode(Node startNode) {
            this.startNode = startNode;
        }

        public Node getEndNode() {
            return endNode;
        }

        public void setEndNode(Node endNode) {
            this.endNode = endNode;
        }

        public Relationship getRelationship() {
            return relationship;
        }

        public void setRelationship(Relationship relationship) {
            this.relationship = relationship;
        }

        @Override
        public String toString() {
            return "Segment{" +
                    "startNode=" + startNode +
                    ", endNode=" + endNode +
                    ", relationship=" + relationship +
                    '}';
        }
    }
}
