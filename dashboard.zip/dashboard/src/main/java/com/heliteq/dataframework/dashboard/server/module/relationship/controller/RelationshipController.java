package com.heliteq.dataframework.dashboard.server.module.relationship.controller;

import com.heliteq.dataframework.dashboard.server.Response.Response;
import com.heliteq.dataframework.dashboard.server.Response.data.Path;
import com.heliteq.dataframework.dashboard.server.Response.data.Relationship;
import com.heliteq.dataframework.dashboard.server.module.relationship.service.RelationshipService;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;

@RestController
@RequestMapping("/data/relationship")
@Api(tags = "Relationship相关操作")
public class RelationshipController {
    @Autowired
    private RelationshipService service;
    //根据关系的标签查询出具有该关系的整条路径
    @GetMapping("/{label}/relations")
    @ApiOperation("根据label找relationship所在路径")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "label", value = "label")
    })
    public Response<Collection<Path.Segment>> getRelationshipByLabel(@PathVariable String label) {
        return new Response(service.getRelationshipByLabel(label));
    }

    //根据关系标签查找出具体的关系属性
    @GetMapping("/{label}")
    @ApiOperation("根据label找relationship具体的关系属性")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "label", value = "label")
    })
    public Response<Collection<Relationship>> getByLabelRelationship(@PathVariable String label) {
        return new Response<>(service.getByLabelRelationship(label));
    }
}
