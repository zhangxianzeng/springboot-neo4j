package com.heliteq.dataframework.dashboard.server.module.query.repository;

import com.heliteq.dataframework.dashboard.server.Response.data.DataResponse;

import java.util.Map;

public interface QueryRepository {
    //用户自定义cql语句
    DataResponse executeCypher(String cql, Map<String, Object> param);

}
