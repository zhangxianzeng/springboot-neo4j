package com.heliteq.dataframework.dashboard.server.module.node.repository.impl;

import com.heliteq.dataframework.dashboard.server.Response.data.DataResponse;
import com.heliteq.dataframework.dashboard.server.Response.data.Node;
import com.heliteq.dataframework.dashboard.server.backend.neo4j.executor.DataExecutor;
import com.heliteq.dataframework.dashboard.server.backend.neo4j.executor.SchemaExecutor;
import com.heliteq.dataframework.dashboard.server.module.node.repository.NodeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

@Component
public class Neo4jNodeRepository implements NodeRepository {

    @Autowired
    private DataExecutor dataRecordResolver;
    @Autowired
    private SchemaExecutor schemaExecutor;

    //按节点id查找相邻节点id
    @Override
    public Collection<Long> getNeighborsIdById(long id) {
        String cql = "MATCH p=(n) -- (m) WHERE id(n) = {id}  RETURN collect(id(m)) AS neighbors";
        Map<String, Object> params = new HashMap<>();
        params.put("id", id);
        Object result = dataRecordResolver.execute(cql, params);
        Object neighbors = ((DataResponse) result).getParams().get("neighbors");
        if (neighbors instanceof Collection)
            return (Collection) neighbors;
        return null;
    }

    //根据节点的label查询出具有同一label的节点
    @Override
    public Collection<Node> getByNodeLabels(String label) {
        String cql = "match(n) where {label} in labels(n) return n";
        Map<String, Object> params = new HashMap<>();
        params.put("label", label);
        return dataRecordResolver.execute(cql, params).getNodes();
    }

    //根据id查找节点详情
    @Override
    public Collection<Node> getNodeById(long id) {
        String cql = "match(n) where id(n) = {id} return n";
        Map<String, Object> params = new HashMap<>();
        params.put("id", id);
        return dataRecordResolver.execute(cql, params).getNodes();
    }


}
