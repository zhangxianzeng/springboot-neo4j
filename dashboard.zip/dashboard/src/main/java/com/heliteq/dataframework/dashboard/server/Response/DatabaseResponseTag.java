package com.heliteq.dataframework.dashboard.server.Response;

/**
 * 作为所有可用数据库响应类型的标记接口
 */
public interface DatabaseResponseTag {
}
