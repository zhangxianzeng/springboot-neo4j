package com.heliteq.dataframework.dashboard.server.module.schema.repository.impl;

import com.heliteq.dataframework.dashboard.common.statics.GraphStatics;
import com.heliteq.dataframework.dashboard.server.Response.data.Node;
import com.heliteq.dataframework.dashboard.server.Response.schema.SchemaResponse;
import com.heliteq.dataframework.dashboard.server.backend.neo4j.executor.DataExecutor;
import com.heliteq.dataframework.dashboard.server.module.schema.repository.SchemaRepository;

import com.heliteq.dataframework.dashboard.server.backend.neo4j.executor.SchemaExecutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class Neo4jSchemaRepository implements SchemaRepository {

    @Autowired
    private SchemaExecutor schemaExecutor;
    @Autowired
    private DataExecutor dataRecordResolver;
    //根据schema中的labels查询出schema可以展开的关系
    @Override
    public Collection<SchemaResponse.Segment> getSchemaByLabels(List<String> labels) {
        String cql = "match p=(g:" + GraphStatics.SCHEMA_NODE_LABEL +") -- () where g."+GraphStatics.SCHEMA_NAME_PROPERTY+"  in {labels} return p";
        Map<String, Object> params = new HashMap<>();
        params.put("labels", labels);
        return schemaExecutor.execute(cql, params).getSegments();
    }
    //根据schema中的labels查询出该schema的节点
    @Override
    public Collection<Node> getSchemaNodeByLabels(List<String> labels1) {
        String cql="match(n:" + GraphStatics.SCHEMA_NODE_LABEL +") where n."+GraphStatics.SCHEMA_NAME_PROPERTY+" in {labels1} return n";
        Map<String, Object> params = new HashMap<>();
        params.put("labels1", labels1);
        return dataRecordResolver.execute(cql, params).getNodes();
    }

}
