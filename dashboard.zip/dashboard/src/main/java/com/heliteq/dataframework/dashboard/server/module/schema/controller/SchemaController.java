package com.heliteq.dataframework.dashboard.server.module.schema.controller;

import com.heliteq.dataframework.dashboard.server.Response.Response;
import com.heliteq.dataframework.dashboard.server.Response.data.Node;
import com.heliteq.dataframework.dashboard.server.Response.schema.SchemaResponse;
import com.heliteq.dataframework.dashboard.server.module.schema.service.SchemaService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;
import java.util.List;

@RestController
@RequestMapping("/data/schema")
@Api(tags = "Schema相关操作")
public class SchemaController {
    @Autowired
    private SchemaService schemaService;

    //根据schema中的labels查询出schema可以展开的关系
    @GetMapping("/labels")
    @ApiOperation("按标签查找可展开的关系")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "labels", value = "标签列表")
    })
    public Response<Collection<SchemaResponse.Segment>> getSchemaByLabels (@RequestParam List<String> labels) {
        return new Response<>(schemaService.getSchemaByLabels(labels));
    }
    //根据schema中的labels查询出该schema的节点
    @GetMapping("/node")
    @ApiOperation("按标签查找schema节点")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "labels", value = "标签列表")
    })
    public Response<Collection<Node>> getSchemaNodeByLabels (@RequestParam List<String> labels) {
        return new Response<>(schemaService.getSchemaNodeByLabels(labels));
    }

}
