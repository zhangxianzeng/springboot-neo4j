package com.heliteq.dataframework.dashboard.server.backend.neo4j.transaction;

import org.neo4j.driver.Driver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConditionalOnClass({Neo4jTransactionManager.class,Driver.class})
public class Neo4jTransactionConfiguration {
    @Autowired
    private Driver driver;

    @Bean
    @ConditionalOnMissingBean(Neo4jTransactionManager.class)
    public Neo4jTransactionManager neo4jTransactionManager() {
        return new Neo4jTransactionManager(driver);
    }
}
