package com.heliteq.dataframework.dashboard.server.Response.data;

import com.heliteq.dataframework.dashboard.server.Response.DatabaseResponseTag;

import java.util.Collection;
import java.util.Map;

public class DataResponse implements DatabaseResponseTag {
    private Collection<Node> nodes;

    private Collection<Relationship> relationships;

    private Collection<Path> paths;

    private Map<String, Object> params;

    public Collection<Node> getNodes() {
        return nodes;
    }

    public void setNodes(Collection<Node> nodes) {
        this.nodes = nodes;
    }

    public Collection<Relationship> getRelationships() {
        return relationships;
    }

    public void setRelationships(Collection<Relationship> relationships) {
        this.relationships = relationships;
    }

    public Collection<Path> getPaths() {
        return paths;
    }

    public void setPaths(Collection<Path> paths) {
        this.paths = paths;
    }

    public Map<String, Object> getParams() {
        return params;
    }

    public void setParams(Map<String, Object> params) {
        this.params = params;
    }

    @Override
    public String toString() {
        return "DataResponse{" +
                "nodes=" + nodes +
                ", relationships=" + relationships +
                ", paths=" + paths +
                ", params=" + params +
                '}';
    }
}
