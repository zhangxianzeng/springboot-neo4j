package com.heliteq.dataframework.dashboard.server.backend.neo4j.executor;

import com.heliteq.dataframework.dashboard.common.statics.GraphStatics;
import com.heliteq.dataframework.dashboard.server.Response.data.Path;
import com.heliteq.dataframework.dashboard.server.Response.schema.SchemaResponse;
import org.neo4j.driver.Value;
import org.neo4j.driver.internal.InternalNode;
import org.neo4j.driver.internal.InternalRelationship;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

@Component
public class SchemaExecutor extends Executor<SchemaResponse> {

    @Override
    protected SchemaResponse createResponse() {
        SchemaResponse response = new SchemaResponse();
        response.setSegments(new ArrayList<>());
        return response;
    }

    @Override
    protected void resolveNode(InternalNode internalNode, SchemaResponse response) {

    }

    @Override
    protected void resolveRelation(InternalRelationship internalRelation, SchemaResponse response) {

    }

    @Override
    protected void resolvePath(org.neo4j.driver.types.Path path, SchemaResponse response) {
        Path p = new Path();
        p.setSegments(new ArrayList<>());
        path.forEach(segment -> {
            String start = segment.start().get(GraphStatics.SCHEMA_NAME_PROPERTY).asString();
            String end = segment.end().get(GraphStatics.SCHEMA_NAME_PROPERTY).asString();
            String relationship = segment.relationship().get(GraphStatics.SCHEMA_NAME_PROPERTY).asString();

            SchemaResponse.Segment s = response.new Segment();
            s.setStartLabel(start);
            s.setEndLabel(end);
            s.setRelationship(relationship);
            response.getSegments().add(s);
        });
    }

    @Override
    protected void resolveParam(String key, Value value, SchemaResponse response) {

    }

}
