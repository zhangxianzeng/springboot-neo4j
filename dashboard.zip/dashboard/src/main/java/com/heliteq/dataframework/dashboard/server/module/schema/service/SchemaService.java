package com.heliteq.dataframework.dashboard.server.module.schema.service;

import com.heliteq.dataframework.dashboard.server.Response.data.Node;
import com.heliteq.dataframework.dashboard.server.Response.schema.SchemaResponse;
import com.heliteq.dataframework.dashboard.server.module.schema.repository.SchemaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;
import java.util.List;

@Service
public class SchemaService {
    @Autowired
    private SchemaRepository schemaRepository;
//根据schema中的labels查询出schema可以展开的关系
    public Collection<SchemaResponse.Segment> getSchemaByLabels (List<String> labels) {
        return schemaRepository.getSchemaByLabels(labels);
    }
    //根据schema中的labels查询出该schema的节点
    public Collection<Node> getSchemaNodeByLabels (List<String> labels) {
        return schemaRepository.getSchemaNodeByLabels(labels);
    }
}
