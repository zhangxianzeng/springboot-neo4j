package com.heliteq.dataframework.dashboard.server.module.node.repository;

import com.heliteq.dataframework.dashboard.server.Response.data.Node;

import java.util.Collection;

public interface NodeRepository {
    //按节点id查找相邻节点id
    Collection<Long> getNeighborsIdById(long id);

    //根据节点的label查询出具有同一label的节点
    Collection<Node> getByNodeLabels(String label);

    //根据id查找节点详情
    Collection<Node> getNodeById(long id);

}
