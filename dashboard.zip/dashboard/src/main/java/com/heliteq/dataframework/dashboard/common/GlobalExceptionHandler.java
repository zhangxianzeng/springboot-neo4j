package com.heliteq.dataframework.dashboard.common;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.heliteq.dataframework.dashboard.server.Response.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.PrintWriter;

@ControllerAdvice
public class GlobalExceptionHandler {
    private final static Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(value = Exception.class)
    public ModelAndView defaultErrorHandler(HttpServletRequest request, HttpServletResponse response, Throwable ex){
        response.setContentType("text/html;charset=UTF-8");
        response.setStatus(500);
        String msg = ex.getMessage();
        logger.error(ex.getMessage(), ex);

        Response r = new Response(null);
        r.setStatusCode(500);
        r.setMessage(msg);
        ObjectMapper objectMapper = new ObjectMapper();

        PrintWriter out = null;
        try {
            out = response.getWriter();
            out.print(objectMapper.writeValueAsString(r));
        } catch(Exception e){
            e.printStackTrace();
        } finally {
            out.close();
        }

        return null;
    }
}
