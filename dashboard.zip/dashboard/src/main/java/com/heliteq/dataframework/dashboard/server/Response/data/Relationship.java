package com.heliteq.dataframework.dashboard.server.Response.data;

import java.util.Map;

public class Relationship {
    private long relationshipId;
    private long startNodeId;
    private long endNodeId;
    private String types;
    private Map<String, Object> properties;

    public long getRelationshipId() {
        return relationshipId;
    }

    public void setRelationshipId(long relationshipId) {
        this.relationshipId = relationshipId;
    }

    public long getStartNodeId() {
        return startNodeId;
    }

    public void setStartNodeId(long startNodeId) {
        this.startNodeId = startNodeId;
    }

    public long getEndNodeId() {
        return endNodeId;
    }

    public void setEndNodeId(long endNodeId) {
        this.endNodeId = endNodeId;
    }

    public String getTypes() {
        return types;
    }

    public void setTypes(String types) {
        this.types = types;
    }

    public Map<String, Object> getProperties() {
        return properties;
    }

    public void setProperties(Map<String, Object> properties) {
        this.properties = properties;
    }

    @Override
    public String toString() {
        return "Relationship{" +
                "relationshipId=" + relationshipId +
                ", startNodeId=" + startNodeId +
                ", endNodeId=" + endNodeId +
                ", types='" + types + '\'' +
                ", properties=" + properties +
                '}';
    }
}
