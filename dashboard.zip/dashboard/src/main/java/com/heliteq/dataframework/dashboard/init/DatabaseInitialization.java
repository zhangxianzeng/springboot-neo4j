package com.heliteq.dataframework.dashboard.init;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;


public abstract class DatabaseInitialization implements ApplicationRunner {
    private Logger logger= LoggerFactory.getLogger(DatabaseInitialization.class);

    @Override
    public void run(ApplicationArguments args) throws Exception {
        logger.info("Database Initialization starting ...");
        long start = System.currentTimeMillis();
        initSchema(args);
        long end = System.currentTimeMillis();
        logger.info("Database Initialization finished in {} ms",end-start);
    }

    abstract protected void initSchema (ApplicationArguments args) throws Exception;
}
