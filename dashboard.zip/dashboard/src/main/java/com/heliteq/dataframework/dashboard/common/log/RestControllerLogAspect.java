package com.heliteq.dataframework.dashboard.common.log;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

@Component
@Aspect
public class RestControllerLogAspect {
    private Logger logger = LoggerFactory.getLogger(RestControllerLogAspect.class);

    @Pointcut("@within(org.springframework.web.bind.annotation.RestController)")
    public void controllerAspect() {
    }


    @Around("controllerAspect()")
    public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
        if (logger.isDebugEnabled()) {
            // 记录客户端信息
            HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
            logger.debug("客户端地址: {}", request.getRemoteHost());
            logger.debug("客户端端口: {}", request.getRemotePort());

            // 记录请求方法信息
            String targetName = joinPoint.getTarget().getClass().getName();
            String methodName = joinPoint.getSignature().getName();
            logger.debug("请求类: {}", targetName);
            logger.debug("请求方法: {}", methodName);
            logger.debug("请求参数: ");
            Object[] args = joinPoint.getArgs();
            for (int i = 0; i < args.length; i++) {
                logger.debug("参数{}: {}", i+1, args[i].toString());
            }
        }

        long start = System.currentTimeMillis();
        try {
            Object response = joinPoint.proceed();
            long end = System.currentTimeMillis();
            logger.debug("返回值: {}", response);
            logger.debug("执行时间: {} ms", (end - start));
            return response;
        } catch (Throwable e) {
            long end = System.currentTimeMillis();
            logger.error("执行时间: {} ms with exception : {}", (end - start), e.getMessage());
            throw e;
        }
    }
}
