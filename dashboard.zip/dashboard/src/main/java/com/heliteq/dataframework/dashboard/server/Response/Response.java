package com.heliteq.dataframework.dashboard.server.Response;

public class Response <T> {

    protected Integer statusCode = 200;
    protected T data;
    protected String message = "success";

    public Response(T t) {
        this.data = t;
    }

    public Response(Integer statusCode,T data, String message) {
        this.statusCode = statusCode;
        this.data = data;
        this.message = message;
    }

    public Integer getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "Response{" +
                "statusCode=" + statusCode +
                ", data=" + data +
                ", message='" + message + '\'' +
                '}';
    }
}
