package com.heliteq.dataframework.dashboard.server.module.schema.repository;

import com.heliteq.dataframework.dashboard.server.Response.data.Node;
import com.heliteq.dataframework.dashboard.server.Response.schema.SchemaResponse;

import java.util.Collection;
import java.util.List;

public interface SchemaRepository {
    //根据schema中的labels查询出schema可以展开的关系
    Collection<SchemaResponse.Segment> getSchemaByLabels(List<String> labels);
    //根据schema中的labels查询出该schema的节点
    Collection<Node> getSchemaNodeByLabels(List<String> labels1);
}
