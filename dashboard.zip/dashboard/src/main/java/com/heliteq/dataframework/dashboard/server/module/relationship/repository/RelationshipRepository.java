package com.heliteq.dataframework.dashboard.server.module.relationship.repository;

import com.heliteq.dataframework.dashboard.server.Response.data.Path;
import com.heliteq.dataframework.dashboard.server.Response.data.Relationship;

import java.util.Collection;


public interface RelationshipRepository {
    //根据关系的标签查询出具有该关系的整条路径
    Collection<Path.Segment> getRelationshipSchemaByLabel(String label);
    //根据关系标签查找出具体的关系属性
    Collection<Relationship> getByLabelRelationship(String label);
}
