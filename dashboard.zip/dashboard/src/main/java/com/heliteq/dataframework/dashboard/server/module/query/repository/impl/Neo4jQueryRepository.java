package com.heliteq.dataframework.dashboard.server.module.query.repository.impl;

import com.heliteq.dataframework.dashboard.server.Response.data.DataResponse;
import com.heliteq.dataframework.dashboard.server.backend.neo4j.executor.DataExecutor;
import com.heliteq.dataframework.dashboard.server.module.query.repository.QueryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class Neo4jQueryRepository implements QueryRepository {
    @Autowired
    private DataExecutor dataRecordResolver;
    //用户自定义cql语句
    @Override
    public DataResponse executeCypher(String cql, Map<String, Object> param) {
        return dataRecordResolver.execute(cql, param);
    }

}
