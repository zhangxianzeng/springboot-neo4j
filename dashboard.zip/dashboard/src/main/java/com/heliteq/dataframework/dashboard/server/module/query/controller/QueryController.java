package com.heliteq.dataframework.dashboard.server.module.query.controller;

import com.heliteq.dataframework.dashboard.server.Response.Response;
import com.heliteq.dataframework.dashboard.server.Response.data.DataResponse;
import com.heliteq.dataframework.dashboard.server.module.query.service.QueryService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/query")
@Api(tags = "自定义查询相关操作")
public class QueryController {
    @Autowired
    private QueryService queryService;

    @GetMapping("/cypher")
    @ApiOperation("执行Cypher语句")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "cql", value = "Cypher语句", example = "match (n) return n limit 10")
    })
    public Response<DataResponse> executeCypher(@RequestParam String cql) {
        return new Response<>(queryService.executeCypher(cql, null));
    }
}
