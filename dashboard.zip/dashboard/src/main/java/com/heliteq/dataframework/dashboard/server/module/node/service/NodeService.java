package com.heliteq.dataframework.dashboard.server.module.node.service;

import com.heliteq.dataframework.dashboard.server.Response.data.Node;
import com.heliteq.dataframework.dashboard.server.module.node.repository.NodeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collection;

@Service
public class NodeService {
    @Autowired
    private NodeRepository nodeRepository;

    //按节点id查找相邻节点id
    public Collection<Long> getNeighborsIdById(long id) {
        return nodeRepository.getNeighborsIdById(id);
    }


    //根据节点的label查询出具有同一label的节点
    public Collection<Node> getByNodeLabels(String label) {
        return nodeRepository.getByNodeLabels(label);
    }

    //根据id查找节点详情
    public Collection<Node> getNodeById(long id) {
        return nodeRepository.getNodeById(id);
    }

}
