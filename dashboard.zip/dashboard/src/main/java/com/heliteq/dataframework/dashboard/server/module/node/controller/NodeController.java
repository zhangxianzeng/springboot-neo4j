package com.heliteq.dataframework.dashboard.server.module.node.controller;

import com.heliteq.dataframework.dashboard.server.Response.Response;
import com.heliteq.dataframework.dashboard.server.Response.data.Node;
import com.heliteq.dataframework.dashboard.server.module.node.service.NodeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collection;

@RestController
@RequestMapping("/data/node")
@Api(tags = "Node相关操作")
public class NodeController {
    @Autowired
    private NodeService nodeService;
    //按节点id查找相邻节点id
    @GetMapping("/{id}/neighbors")
    @ApiOperation("按节点id查找相邻节点id")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "节点id")
    })
    public Response<Collection<Long>> getNeighborsIdById(@PathVariable long id) {
        return new Response<>(nodeService.getNeighborsIdById(id));
    }

    //根据节点的label查询出具有同一label的节点
    @GetMapping("/label/{label}")
    @ApiOperation("查询具有某个label的所有节点")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "label", value = "节点label")
    })
    public Response<Collection<Node> >getByNodeLabels(@PathVariable String label) {
        return new Response<>(nodeService.getByNodeLabels(label));
    }

    //根据id查找节点详情
    @GetMapping("/{id}")
    @ApiOperation("根据id查找节点详情")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "id", value = "节点id")
    })
    public Response<Collection<Node> >getNodeById(@PathVariable long id) {
        return new Response<>(nodeService.getNodeById(id));
    }

}