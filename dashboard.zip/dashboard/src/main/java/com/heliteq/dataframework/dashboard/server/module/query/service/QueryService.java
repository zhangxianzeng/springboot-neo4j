package com.heliteq.dataframework.dashboard.server.module.query.service;

import com.heliteq.dataframework.dashboard.server.Response.data.DataResponse;
import com.heliteq.dataframework.dashboard.server.module.query.repository.QueryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class QueryService {
    @Autowired
    private QueryRepository queryRepository;
//用户自定义cql语句
    public DataResponse executeCypher (String cql, Map<String, Object> param) {
        return queryRepository.executeCypher(cql, param);
    }
}
