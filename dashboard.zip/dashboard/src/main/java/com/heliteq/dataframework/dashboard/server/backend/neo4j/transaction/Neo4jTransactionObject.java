package com.heliteq.dataframework.dashboard.server.backend.neo4j.transaction;

import org.neo4j.driver.Session;
import org.neo4j.driver.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Neo4jTransactionObject {
    private Session session;
    private Transaction transaction;
    private Logger logger = LoggerFactory.getLogger(Neo4jTransactionManager.class);


    public Neo4jTransactionObject(Session session) {
        this.session = session;
        this.transaction = session.beginTransaction();
    }

    public void setSession(Session session) {
        if (this.transaction.isOpen()) {
            throw new IllegalStateException("current transaction is opening.");
        }
        if (this.session.isOpen()) {
            throw new IllegalStateException("current session is opening.");
        }
        this.session = session;
        this.transaction = session.beginTransaction();
    }

    public Session getSession() {
        return session;
    }

    public Transaction getTransaction() {
        return transaction;
    }

    protected void commit() {
        this.transaction.commit();
        this.session.close();
    }

    protected void rollback() {
        this.transaction.rollback();
        this.session.close();
    }

    protected void close() {
        this.transaction.close();
        this.session.close();
    }

    @Override
    protected void finalize() throws Throwable {
        if (this.transaction.isOpen()) {
            logger.warn("transaction is closed by finalize !");
            this.transaction.close();
        }
        if (this.session.isOpen()) {
            logger.warn("session is closed by finalize !");
            this.session.close();
        }
    }
}
