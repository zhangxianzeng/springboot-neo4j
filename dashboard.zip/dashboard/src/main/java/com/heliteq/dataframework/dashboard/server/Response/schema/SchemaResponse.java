package com.heliteq.dataframework.dashboard.server.Response.schema;

import com.heliteq.dataframework.dashboard.server.Response.DatabaseResponseTag;

import java.util.Collection;

public class SchemaResponse implements DatabaseResponseTag {
    private Collection<Segment> segments;

    public Collection<Segment> getSegments() {
        return segments;
    }

    public void setSegments(Collection<Segment> segments) {
        this.segments = segments;
    }

    @Override
    public String toString() {
        return "SchemaResponse{" +
                "segments=" + segments +
                '}';
    }

    public class Segment {
        private String startLabel;
        private String endLabel;
        private String relationship;

        public String getStartLabel() {
            return startLabel;
        }

        public void setStartLabel(String startLabel) {
            this.startLabel = startLabel;
        }

        public String getEndLabel() {
            return endLabel;
        }

        public void setEndLabel(String endLabel) {
            this.endLabel = endLabel;
        }

        public String getRelationship() {
            return relationship;
        }

        public void setRelationship(String relationship) {
            this.relationship = relationship;
        }

        @Override
        public String toString() {
            return "Segment{" +
                    "startLabel='" + startLabel + '\'' +
                    ", endLabel='" + endLabel + '\'' +
                    ", relationship='" + relationship + '\'' +
                    '}';
        }
    }
}
